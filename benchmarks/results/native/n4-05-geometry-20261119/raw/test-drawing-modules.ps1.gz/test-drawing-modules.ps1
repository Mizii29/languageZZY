param([Parameter(Mandatory=$true)][string]$Executable,[Parameter(Mandatory=$true)][string]$Output)
$ErrorActionPreference="Stop"
$exe=(Resolve-Path -LiteralPath $Executable).Path
if(Test-Path -LiteralPath $Output) {throw "Choose new evidence path"}
$folder=Join-Path $env:TEMP ("ZZY 原生模块 "+[guid]::NewGuid())
New-Item -ItemType Directory -Path $folder | Out-Null
$source=Join-Path $folder "headless.zzy"
[IO.File]::WriteAllText($source,'(zno)c:=sketch.canvas(80,80,"headless");(zno)p:=sketch.pen(c,"p");sketch.forward(p,10);io.print("ready");io.input("");',[Text.UTF8Encoding]::new($false))
$s=[Diagnostics.ProcessStartInfo]::new()
$s.FileName=$exe;$s.Arguments='run "'+$source+'" --diagnostic-format json'
$s.WorkingDirectory=$folder;$s.UseShellExecute=$false;$s.CreateNoWindow=$true
$s.RedirectStandardInput=$true;$s.RedirectStandardOutput=$true;$s.RedirectStandardError=$true
$s.EnvironmentVariables["PATH"]="";$s.EnvironmentVariables["PYTHONPATH"]="invalid-zzy-native"
$p=[Diagnostics.Process]::new();$p.StartInfo=$s
try {
    $null=$p.Start();$line=$p.StandardOutput.ReadLineAsync();$stderr=$p.StandardError.ReadToEndAsync()
    if(-not $line.Wait(10000) -or $line.Result -cne "ready") {throw "drawing never reached input safe point"}
    $modules=@($p.Modules | ForEach-Object {[ordered]@{name=$_.ModuleName;path=$_.FileName}})
    if($modules.Count -eq 0 -or @($modules | Where-Object {$_.name -match "^(python|_tkinter|tcl|tk[0-9])"}).Count -ne 0) {throw "Python/GUI module found"}
    $children=@(Get-CimInstance Win32_Process -Filter ("ParentProcessId="+$p.Id) | Select-Object -ExpandProperty Name)
    if(@($children | Where-Object {$_ -notmatch "^conhost\.exe$"}).Count) {throw "unexpected child process"}
    $tail=$p.StandardOutput.ReadToEndAsync();$p.StandardInput.WriteLine("");$p.StandardInput.Close()
    if(-not $p.WaitForExit(10000) -or $p.ExitCode -ne 0 -or $stderr.Result -cne "" -or $tail.Result -cne "") {throw "drawing failed after input"}
    $record=[ordered]@{passed=$true;executable=$exe;sha256=(Get-FileHash -LiteralPath $exe).Hash;source=[IO.File]::ReadAllText($source);exit_code=$p.ExitCode;stdout=$line.Result;stderr=$stderr.Result;modules=$modules;children=$children;path="";pythonpath="invalid-zzy-native"}
    [IO.File]::WriteAllText([IO.Path]::GetFullPath($Output),($record|ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false))
    "Drawing actual modules: PASS"
} finally {
    if($p.Id -and -not $p.HasExited) {$p.Kill();$p.WaitForExit()}
    $p.Dispose()
    $resolved=[IO.Path]::GetFullPath($folder)
    $temp=[IO.Path]::GetFullPath($env:TEMP).TrimEnd("\")+"\"
    if(-not $resolved.StartsWith($temp,[StringComparison]::OrdinalIgnoreCase)) {throw "unexpected cleanup path"}
    Remove-Item -LiteralPath $resolved -Recurse -Force
}
