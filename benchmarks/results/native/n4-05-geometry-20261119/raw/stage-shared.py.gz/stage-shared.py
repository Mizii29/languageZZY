from difflib import unified_diff
from hashlib import sha256
import json
from pathlib import Path
import subprocess

def git(*args):
    return subprocess.check_output(["git", *args])

work = Path(__file__).resolve().parent
assert git("rev-parse", "HEAD").decode().strip() == "d123ccac944df90e2f8425014222181d5cf01d90"
sections = {
    "docs/development/todo.md": "### N4-05 首批交接",
    "docs/development/development-log.md": "## N4-05 首批几何",
    "docs/development/native-runtime-plan.md": "### N4-05 首批交付",
    "docs/development/test-coverage.md": "## N4-05 首批原生 Sketch",
    "skills/zzy/SKILL.md": "## N4-05 当前状态（首批）",
}
selected = {}
before = json.loads((work / "pre-doc-hashes.json").read_text(encoding="utf-8"))
for name, marker in sections.items():
    text = Path(name).read_text(encoding="utf-8")
    assert text.count(marker) == 1, name
    prefix, section = text.split(marker)
    raw_prefix = Path(name).read_bytes().split(marker.encode())[0].rstrip(b"\r\n")
    candidates = [raw_prefix + end for end in (b"", b"\n", b"\n\n", b"\r\n", b"\r\n\r\n")]
    assert before[name] in {sha256(s).hexdigest() for s in candidates}, name
    selected[name] = git("show", f"HEAD:{name}").decode().rstrip() + "\n\n" + marker + section

own = set(sections) | {"native_runtime/README.md"}
for name, expected in before.items():
    if name not in own:
        assert sha256(Path(name).read_bytes()).hexdigest() == expected, name
assert sha256(Path("docs/requirement.md").read_bytes()).hexdigest() == "b099c19fc339ce1dc1aab7e9d6c8126a9c5c9ace3d31b969a0623df90f521d2b"
patch = "".join("".join(unified_diff(git("show", f":{name}").decode().splitlines(keepends=True),
    text.splitlines(keepends=True), f"a/{name}", f"b/{name}")) for name, text in selected.items()).encode()
subprocess.run(["git", "apply", "--cached", "--check", "-"], input=patch, check=True)
subprocess.run(["git", "apply", "--cached", "-"], input=patch, check=True)
for name, text in selected.items():
    assert git("show", f":{name}").decode() == text, name
print("Staged five phase appendices; existing document contents and unrelated fingerprints preserved.")
