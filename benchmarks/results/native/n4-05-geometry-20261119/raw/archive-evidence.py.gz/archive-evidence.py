from hashlib import sha256
import gzip
import json
from pathlib import Path
import platform
import subprocess

root = Path.cwd()
work = root / "dist/native-n4-05-geometry"
output = root / "benchmarks/results/native/n4-05-geometry-20261119"
def digest(p):
    return sha256(p.read_bytes()).hexdigest()
def read(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))

for cfg in ("debug", "release"):
    core = read(work / f"core-{cfg}.json")
    assert core["passed_core"] == 550 and core["deferred"] == 0 and len(core["records"]) == 550
    assert all(r["passed"] and not r["timeout"] for r in core["records"])
    acceptance = read(work / f"accept-{cfg}-final/report.json")
    assert acceptance["passed"] and len(acceptance["records"]) == 82
assert read(work / "published.json")["passed"]
assert len(read(work / "published.json")["records"]) == 71
assert read(work / "drawing-modules.json")["passed"]
assert read(work / "ci-static-final/report.json")["passed"]

audit = {"stage": "N4-05 geometry subset; full stage incomplete",
    "base_commit": subprocess.check_output(["git", "rev-parse", "HEAD"]).decode().strip(),
    "platform": platform.platform(), "development_python": platform.python_version(),
    "requirement_sha256": digest(root / "docs/requirement.md"),
    "artifacts": {}, "native_sources": {},
    "source_scope": "Current source files; manual/GUI/complete Python tests not run"}
assert audit["requirement_sha256"] == "b099c19fc339ce1dc1aab7e9d6c8126a9c5c9ace3d31b969a0623df90f521d2b"
for cfg in ("debug", "release"):
    directory = root / f"build/native-{cfg}" / cfg.title()
    for p in sorted(directory.glob("*.exe")):
        audit["artifacts"][p.relative_to(root).as_posix()] = digest(p)
for p in sorted((root / "native_runtime").rglob("*")):
    if p.is_file() and (p.name == "CMakeLists.txt" or p.suffix in (".hpp", ".cpp", ".ps1", ".py", ".zzy", ".cmake", ".json")):
        audit["native_sources"][p.relative_to(root).as_posix()] = digest(p)
release = root / "build/native-release/Release/zzy-native.exe"
published = Path(read(work / "published.json")["exe"])
assert digest(release) == digest(work / "install/bin/zzy-native.exe") == digest(published)
audit["published_executable"] = str(published)
audit["published_sha256"] = digest(published)
output.mkdir(parents=True, exist_ok=False)
(output / "audit.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

files = [p for p in work.iterdir() if p.is_file() and p.suffix in (".log", ".json", ".txt", ".ps1", ".py")]
for folder in ("accept-debug-final", "accept-release-final", "ci-static-final"):
    files += [p for p in (work / folder).rglob("*") if p.is_file()]
entries = []
for p in sorted(files):
    key = p.relative_to(work).as_posix()
    target = output / "raw" / (key + ".gz")
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = p.read_bytes()
    target.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(target.read_bytes()) == raw
    entries.append({"path": key, "archive": target.relative_to(output).as_posix(),
                    "bytes": len(raw), "sha256": sha256(raw).hexdigest()})
(output / "index.json").write_text(json.dumps(entries, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(f"Archived {len(entries)} raw records; executable and source hashes verified.")
